## Project Overview

This project is a responsive portfolio website meant to demonstrate advanced CSS techniques 
including Flexbox, CSS Grid, pseudo-classes, pseudo-elements, combinators, and selectors in 
order to create a professional, interactive web portfolio.

### Web Page Structure
- **Single-page portfolio layout** with semantic HTML5 structure
- **Header**: Contains logo, navigation menu, and call-to-action button
- **Main Section**: Features a responsive grid of multiple projects showcasing different technologies
- **Sidebar**: Displays personal information, skills, and social links
- **Footer**: Includes copyright information, build details, and policy links
- **Fully Responsive Design** that adapts seamlessly to desktop and mobile viewports

## File Structure
```
CS601_HW3_Rogers/
├── index.html        # Main HTML file with semantic structure
├── css/
│   └── styles.css    # Complete CSS styling with all required features
└── README.md         # This documentation file
```
