/**
 * Document ready function to initialize form functionality
 */
document.addEventListener('DOMContentLoaded', () => {
    initializeForm();
});
/**
 * Initialize form event listeners and validation
 */
const initializeForm = () => {
    const form = document.getElementById('subscriptionForm');
    const formFields = getFormFields();

    setupRealTimeValidation(formFields);

    form.addEventListener('submit', handleFormSubmission);
};

/**
 * Get all form field elements
 */
const getFormFields = () => ({
    firstName: document.getElementById('firstName'),
    lastName: document.getElementById('lastName'),
    email: document.getElementById('email'),
    package: document.getElementById('package'),
    subscribe: document.getElementById('subscribe')
});

/**
 * Setup real-time validation for all form fields
 */
const setupRealTimeValidation = (fields) => {
    Object.entries(fields).forEach(([fieldName, field]) => {
        field.addEventListener('blur', () => validateSingleField(fieldName, field));
        field.addEventListener('input', () => clearFieldError(fieldName, field));
    });
};

/** 
 * Validation rules configuration object
 */
const validationRules = {
    firstName: {
        validate: (value) => /^[A-Za-z]{2,}$/.test(value.trim()),
        message: 'First name must contain at least 2 alphabetic characters only.'
    },
    lastName: {
        validate: (value) => /^[A-Za-z]{2,}$/.test(value.trim()),
        message: 'Last name must contain at least 2 alphabetic characters only.'
    },
    email: {
        validate: (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim()),
        message: 'Please enter a valid email address (e.g., user@example.com).'
    },
    package: {
        validate: (value) => ['Bronze', 'Silver', 'Gold', 'Platinum'].includes(value),
        message: 'Please select a valid package option.'
    },
    subscribe: {
        validate: (checked) => checked === true,
        message: 'You must agree to subscribe to proceed.'
    }
};

/**
 * Validate a single form field using arrow function
 */
const validateSingleField = (fieldName, field) => {
    const rule = validationRules[fieldName];
    if (!rule) return true;

    const getValue = () => {
        switch (field.type) {
            case 'checkbox':
                return field.checked;
            default:
                return field.value;
        }
    };
    const isValid = rule.validate(getValue());

    if (!isValid) {
        showFieldError(fieldName, rule.message);
    } else {
        clearFieldError(fieldName);
        showFieldSuccess(fieldName);
    }
    return isValid;
};

/**
 * Validate all form fields using map() higher-order function
 */
const validateAllFields = () => {
    const fields = getFormFields();

    const validationResults = Object.entries(fields).map(([fieldName, field]) => {
        return {
            fieldName,
            isValid: validateSingleField(fieldName, field)
        };
    });
    return validationResults;
};

/**
 * Check if all validations passed using filter() higher-order function
 */
const allValidationsPassed = (validationResults) => {
    const failedValidations = validationResults.filter(result => !result.isValid);
    return failedValidations.length === 0;
};

/**
 * Display error message for a specific field
 */
const showFieldError = (fieldName, message) => {
    const errorElement = document.getElementById(`${fieldName}Error`);
    const fieldGroup = document.getElementById(fieldName).closest('.form-group');

    if (errorElement && fieldGroup) {
        errorElement.textContent = message;
        errorElement.classList.add('show');
        fieldGroup.classList.add('error');
        fieldGroup.classList.remove('success');
    }
};

/**
 * Clear error message for a specific field
 */
const clearFieldError = (fieldName) => {
    const errorElement = document.getElementById(`${fieldName}Error`);
    const fieldGroup = document.getElementById(fieldName).closest('.form-group');

    if (errorElement && fieldGroup) {
        errorElement.textContent = '';
        errorElement.classList.remove('show');
        fieldGroup.classList.remove('error');
    }
};

/**
 * Show success state for a field
 */
const showFieldSuccess = (fieldName) => {
    const fieldGroup = document.getElementById(fieldName).closest('.form-group');

    if (fieldGroup) {
        fieldGroup.classList.add('success');
        fieldGroup.classList.remove('error');
    }
};

/**
 * Handle form submission with validation
 */
const handleFormSubmission = (event) => {
    event.preventDefault();

    const validationResults = validateAllFields();

    if (allValidationsPassed(validationResults)) {
        displaySuccessMessage();
        hideForm();
    } else {
        focusFirstErrorField(validationResults);
    }
};

/**
 * Focus on the first field with validation error
 */
const focusFirstErrorField = (validationResults) => {
    const firstError = validationResults.find(result => !result.isValid);

    if (firstError) {
        const errorField = document.getElementById(firstError.fieldName);
        if (errorField) {
            errorField.focus();
            errorField.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
};

/**
 * Generate success message with user data
 */
const generateSuccessMessage = () => {
    const fields = getFormFields();

    const userData = {
        firstName: fields.firstName.value.trim(),
        lastName: fields.lastName.value.trim(),
        email: fields.email.value.trim(),
        package: fields.package.value
    };
    return `
        <div class="summary-content">
            <p><strong>Thank you, ${userData.firstName} ${userData.lastName}, for subscribing!</strong></p>
            <p>Your email <strong>${userData.email}</strong> is registered with our <strong>${userData.package}</strong> package.</p>
            <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.3);">
                <p style="font-size: 0.9em; opacity: 0.8;">You will receive a confirmation email shortly.</p>
            </div>
        </div>
    `;    
};

/**
 * Display success message and user summary
 */
const displaySuccessMessage = () => {
    const successDiv = document.getElementById('successMessage');
    const summaryContent = document.getElementById('summaryContent');

    if (successDiv && summaryContent) {
        summaryContent.innerHTML = generateSuccessMessage();
        successDiv.style.display = 'block';

        successDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
};

/**
 * Hide the form after successful using DOM manipulation
 */
const hideForm = () => {
    const form = document.getElementById('subscriptionForm');

    if (form) {
        form.style.transition = 'opacity 0.5s ease-out, transform 0.5s ease-out';
        form.style.opacity = '0';
        form.style.transform = 'translateY(-20px)';

        setTimeout(() => {
            form.style.display = 'none';
        }, 500);
    }
};

/**
 * Utility function to get all required field names using filter()
 */
const getRequiredFields = () => {
    return Object.keys(validationRules).filter(fieldName => {
        return true;
    });
};

/**
 * Advanced validation: Check for common email typos and suggest corrections
 */
const validateEmailWithSuggestions = (email) => {
    const commonDomains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com'];
    const basicValidation = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());

    if (!basicValidation) {
        return { isValid: false, suggestion: null };
    }
    const domain = email.split('@')[1];

    const suggestions = commonDomains.map(commonDomain => {
        const distance = calculateLevenshteinDistance(domain, commonDomain);
        return { domain: commonDomain, distance };
    }).filter(item => item.distance <= 2 && item.distance > 0);

    return {
        isValid: true,
        suggestions: suggestions.length > 0 ? suggestions[0].domain : null
    };
};

/**
 * Calculate Levenshtein distance between two strings
 */
const calculateLevenshteinDistance = (str1, str2) => {
    const matrix = Array(str2.length + 1).fill(null).map(() => Array(str1.length +1).fill(null));

    for (let i = 0; i <= str1.length; i += 1) {
        matrix[0][i] = i;
    }
    for (let j = 0; j <= str2.length; j += 1) {
        matrix[j][0] = j;
    }

    for (let j = 1; j <= str2.length; j +=1) {
        for (let i = 1; i <= str1.length; i += 1) {
            const indicator = str1[i - 1] === str2[j - 1] ? 0 : 1;
            matrix[j][i] = Math.min(
                matrix[j][i - 1] + 1, // deletion
                matrix[j - 1][i] + 1, // insertion
                matrix[j - 1][i - 1] + indicator // substitution
            );
        }
    }
    return matrix[str2.length][str1.length];
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        validateSingleField,
        validateAllFields,
        allValidationsPassed,
        generateSuccessMessage,
        getRequiredFields
    };
}
