# Fresh Market Grocery - Inventory Management Application

## Project Overview

This is a React-based inventory management web application for Fresh Market Grocery store (a notional market). The
application displays the store's current inventory in a clean, user-friendly interface with dynamic rendering of
product information.

## Features

- **React Components**: Modular component architecture with reusable InventoryItem components
- **Dynamic Data Loading**: Inventory data loaded from JSON file
- **Responsive Design**: Mobile-friendly layout that adapts to different screen sizes
- **Professional Styling**: Modern CSS with gradient backgrounds, hover effects, and animations
- **Complete Store Interface**: Includes store logo, name, tagline, inventory list, and footer

## Project Structure

```
CS601_HW5_Rogers/
├── index.html          # Main HTML file with React components
├── styles.css          # CSS styling for the application
├── inventory.json      # Inventory data (7 items)
└── README.md           # Project documentation
```

## Technical Implementation

### React Setup
- **Approach**: Non-build setup using React CDN (v18)
- **Libraries Used**:
  - React (via unpkg.com CDN)
  - ReactDOM (via unpkg.com CDN)
  - Babel Standalone (for JSX transformation)

### Components

#### 1. **Inventory Component**
  - Reusable component that accepts props (sku, name, qty, price)
  - Displays individual item details with formatted pricing
  - Includes visual styling for each field

#### 2. **InventoryList Component**
  - Renders the complete list of inventory items
  - Uses array mapping to generate InventoryItem components
  - Passes data via props to child components

#### 3. **Header Component**
  - Displays store name and logo
  - Includes animated SVG logo
  - Shows store tagline

#### 4. **Footer Component**
  - Contains copyright information
  - Displays contact details

#### 5. **App Component (main)**
  - Root component that orchestrates the application
  - Manages state using React hooks (useState, useEffect)
  - Handles data fetching from inventory.json
  - Implements loading and error states

## Notes

### Why Non-Build Approach?
The non-build approach was chosen to:
  - Simplify setup
  - Allow for quick testing and iteration
  - Focus on React concepts rather than build tools
  - Meet flexibility requirements