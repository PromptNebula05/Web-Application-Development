## Project Description
This assignment implements a Country Management System using TypeScript. The
application demonstrates the use of interfaces, classes, inheritance, type
assertions, and type predicates to create a type-safe and flexible system for
managing information about various countries.

## Features
- **ICountry Interface**: Defines the contract for all country types
- **Three Country Classes**:
  - RainyCountry: Manages countries with rainfall data
  - SnowyCountry: Manages countries with snowfall data
  - IslandCountry: Manages countries with land mass data
- **Type-Safe Filtering**: Uses type predicates and assertions to filter snowy countries
- **DOM Rendering**: Displays all countries and filtered snowy countries with total snow levels

## Project Structure
```
CS601_HW4_Rogers/
├── Module4_Assignment/
│   └── country-app/
│       ├── package-lock.json
│       ├── package.json
│       ├── tsconfig.json
│       ├── src/
│       │   └── app.ts
│       └── public/
│           ├── index.html
│           └── app.js (generated)
└── README.md
```

## Setup Instructions
1. Ensure Node.js is installed on system
2. Navigate to the `country-app` directory
3. Run `npm install` to install TypeScript compiler and dependencies
4. Compile TypeScript: `npx tsc`
5. Open `public/index.html' in web browser
