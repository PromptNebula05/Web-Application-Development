"use strict";
/**
 * MET CS601 - Assignment 4
 * Country Management System
 */
// Part 3b & 3c: Create classes that implement ICountry interface
// 1) RainyCountry class
class RainyCountry {
    constructor(name, rainLevel) {
        this.name = name;
        this.rainLevel = rainLevel;
    }
    getInfo(element) {
        element.textContent = `${this.name} has a rain level of ${this.rainLevel.toFixed(2)} inches.`;
        return element;
    }
}
// 2) SnowyCountry class
class SnowyCountry {
    constructor(name, snowLevel) {
        this.name = name;
        this.snowLevel = snowLevel;
    }
    getInfo(element) {
        element.textContent = `${this.name} has a snow level of ${this.snowLevel.toFixed(2)} inches.`;
        return element;
    }
}
// 3) IslandCountry class
class IslandCountry {
    constructor(name, landSize) {
        this.name = name;
        this.landSize = landSize;
    }
    getInfo(element) {
        element.textContent = `${this.name} has a land size of ${this.landSize.toLocaleString()} square kilometers.`;
        return element;
    }
}
// Part 4: Sample data - list of various types of country objects
const countries = [
    new RainyCountry("United States", 28),
    new SnowyCountry("Norway", 50),
    new RainyCountry("Brazil", 40),
    new IslandCountry("Japan", 145937),
    new SnowyCountry("Sweden", 30),
    new IslandCountry("Australia", 2968464)
];
// Part 5: Create an empty list for storing only SnowyCountry objects
const snowyCountriesList = [];
// Part 6a: Type predicate function to check if a country is a SnowyCountry
function isSnowyCountry(country) {
    return country.snowLevel !== undefined;
}
// Function to filter snowy countries
function filterSnowyCountry(country) {
    // Check if the country has a snowLevel property
    if (isSnowyCountry(country)) {
        return country; // Return the country object if it's a SnowyCountry
    }
    return null; // Otherwise return null
}
// Part 6b & 6c: Filter and build the snowyCountriesList
countries.forEach(country => {
    const result = filterSnowyCountry(country);
    if (result !== null) {
        // Use type assertion since we know result is SnowyCountry when not null
        snowyCountriesList.push(result);
    }
});
// Part 7: Function to calculate total annual snow level
function calculateTotalSnowLevel(snowyCountries) {
    return snowyCountries.reduce((total, country) => total + country.snowLevel, 0);
}
// Function to render information to the DOM
function renderCountryInformation() {
    const outputDiv = document.getElementById('output');
    if (!outputDiv) {
        console.error('Output div not found');
        return;
    }
    // Clear existing content
    outputDiv.innerHTML = '';
    // Part 7a: Display all country information
    const allCountriesSection = document.createElement('section');
    allCountriesSection.innerHTML = '<h2>All Countries Information</h2>';
    countries.forEach(country => {
        const countryElement = document.createElement('p');
        country.getInfo(countryElement);
        allCountriesSection.appendChild(countryElement);
    });
    // Part 7b: Display snowy countries information and total snow level
    const snowyCountriesSection = document.createElement('section');
    snowyCountriesSection.innerHTML = '<h2>Snowy Countries Information</h2>';
    snowyCountriesList.forEach(country => {
        const snowyCountryElement = document.createElement('p');
        country.getInfo(snowyCountryElement);
        snowyCountriesSection.appendChild(snowyCountryElement);
    });
    // Display total annual snow level
    const totalSnowLevel = calculateTotalSnowLevel(snowyCountriesList);
    const totalElement = document.createElement('p');
    totalElement.innerHTML = `<strong>Total Annual Snow Level: ${totalSnowLevel.toFixed(2)} inches</strong>`;
    snowyCountriesSection.appendChild(totalElement);
    // Append sections to output div
    outputDiv.appendChild(allCountriesSection);
    outputDiv.appendChild(snowyCountriesSection);
}
// Call the function when the page loads
document.addEventListener('DOMContentLoaded', renderCountryInformation);
