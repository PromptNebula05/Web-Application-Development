# CS601 HW2 - Drag & Drop Food Categorizer

## Overview
This project is a dynamic web application that demonstrates asynchronous web operations and interactive user interfaces. Users can drag and drop food items to categorize them into fruits and vegetables using modern web technologies.

## Features
- **Asynchronous Data Fetching**: Uses Fetch API to load JSON data
- **Drag & Drop Interface**: HTML5 drag-and-drop with visual feedback
- **Responsive Design**: Works on desktop and mobile devices
- **Real-time Validation**: Instant feedback for categorization
- **Game Completion**: Celebration effects and reset functionality

## Fiel Structure
```
CS601_HW2_Rogers/
├── index.html          # Main HTML structure
├── styles.css          # CSS styling and animations
├── script.js           # JavaScript functionality
├── data.json           # JSON data with food items
└── README.md           # Project documentation
```
