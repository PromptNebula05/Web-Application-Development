/**
 * Description: A web application that fetches JSON data and implements drag-and-drop functionality
to categorize food items into fruits and vegetables.
*/ 
 
// Global variables to store application state
let allItems = [];
let draggedElement = null;

/**
 * Initialize the application when the DOM is fully loaded
 */
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

/**
 * Main initialization function that sets up the application
 */
async function initializeApp() {
    try {
        updateStatus('Loading items from server...', 'info');

        // Fetch data from JSON file
        await fetchAndDisplayItems();

        // Set up drag and drop event handlers
        setupDragAndDropHandlers();

        updateStatus('Application loaded successfully! Start dragging items to categorize them.', 'success');

    } catch (error) {
        console.error('Error initializing application:', error);
        updateStatus('Error loading application. Please check the console for details.', 'error');
    }
}

/**
 * Fetch JSON data using the Fetch API and display items
 */
async function fetchAndDisplayItems() {
    try {
        // Fetch data from the JSON file
        const response = await fetch('./data.json');

        // Check if the request was successful
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        // Parse the JSON data
        const data = await response.json();
        allItems = data.items;

        // Validate that we have items
        if (!allItems || allItems.length === 0) {
            throw new Error('No items found in the JSON data');
        }

        // Shuffle items to create mixed display and render them
        const shuffledItems = shuffleArray([...allItems]);
        renderItems(shuffledItems);

        console.log('Successfully loaded', allItems.length, 'items');

    } catch (error) {
        console.error('Error fetching data:', error);
        throw new Error('Failed to load data: ' + error.message);
    }
}

/** 
 * Higher-order function to shuffle an array using Fisher-Yates algorithm
 * @param {Array} array - The array to shuffle
 * @returns {Array} - The shuffled array
 */
function shuffleArray(array) {
    // Create a copy of the array to avoid mutating the original
    const shuffled = [...array];

    // Fisher-Yates shuffle algorithm
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }

    return shuffled;
}

/**
 * Higher-order function to create item elements using map
 * @param {Array} items - Array of item objects
 */
function renderItems(items) {
    const container = document.getElementById('items-container');

    // Clear existing items
    container.innerHTML = '';

    // Use map to transform items into DOM elements
    const itemElements = items.map(item => createItemElement(item));

    // Use forEach to append each element to the container
    itemElements.forEach(element => {
        container.appendChild(element);
    });
}

/**
 * Create a draggable DOM element for an item
 * @param {object} item - The item object with id, name, category, etc.
 * @returns {HTMLElement} - The created item element
 */
function createItemElement(item) {
    const itemDiv = document.createElement('div');
    itemDiv.className = 'draggable-item';
    itemDiv.draggable = true;
    itemDiv.setAttribute('data-id', item.id);
    itemDiv.setAttribute('data-category', item.category);

    // Create item content structure
    itemDiv.innerHTML = `
        <div class="item-name">${item.name}</div>
        <div class="item-description">${item.description}</div>
        <span class="item-category">${item.category}</span>
        `;

        // Set background color if available
        if (item.color) {
            itemDiv.style.borderLeftColor = item.color;
            itemDiv.style.borderLeftWidth = '4px';
        }

        return itemDiv;
}

/**
 * Set up all drag and drop event handlers
 */
function setupDragAndDropHandlers() {
    setupItemDragHandlers();
    setupDropZoneHandlers();
}

/**
 * Set up drag event handlers for draggable items
 */
function setupItemDragHandlers() {
    const itemsContainer = document.getElementById('items-container');

    // Use event delegation to handle drag events for all items
    itemsContainer.addEventListener('dragstart', handleDragStart);
    itemsContainer.addEventListener('dragend', handleDragEnd);
}

/**
 * Set up drop zone event handlers
 */
function setupDropZoneHandlers() {
    const dropZones = document.querySelectorAll('.drop-zone');

    // Add event listeners to each drop zone
    dropZones.forEach(zone => {
        zone.addEventListener('dragover', handleDragOver);
        zone.addEventListener('drop', handleDrop);
        zone.addEventListener('dragenter', handleDragEnter);
        zone.addEventListener('dragleave', handleDragLeave);
    });
}

/**
 * Handle dragstart event - fired when user starts dragging an element
 * @param {DragEvent} event - The drag event
 */
function handleDragStart(event) {
    // Store reference to the dragged element
    draggedElement = event.target;

    // Add visual feedback
    event.target.classList.add('dragging');

    // Set drag effect
    event.dataTransfer.effectAllowed = 'move';

    console.log('Started dragging:', event.target.getAttribute('data-category'), 'item');
}

/**
 * handle dragend event - fired when dragging ends
 * @param {DragEvent} event - The drag event
 */
function handleDragEnd(event) {
    // Remove visual feedback
    event.target.classList.remove('dragging');

    // Clear dragged element reference
    draggedElement = null;

    console.log('Drag ended');
}

/**
 * Handle dragover event - fired when a dragged element is over a drop target
 * @param {DragEvent} event - The drag event
 */
function handleDragOver(event) {
    // Prevent default behavior to allow drop
    event.preventDefault();

    // Set drop effect
    event.dataTransfer.dropEffect = 'move';
}

/**
 * Handle dragenter event - fired when a dragged element enters a drop zone
 * @param {DragEvent} event - The drag event
 */
function handleDragEnter(event) {
    event.preventDefault();

    // Add visual feedback to drop zone
    if (event.target.classList.contains('drop-zone')) {
        event.target.classList.add('drag-over');
    }
}

/**
 * Handle dragleave event - fired when a dragged element leaves a drop zone
 * @param {DragEvent} event - The drag event
 */
function handleDragLeave(event) {
    // Remove visual feedback from drop zone
    if (event.target.classList.contains('drop-zone')) {
        event.target.classList.remove('drag-over');
    }
}

/**
 * Handle drop event - fired when user releases the dragged element over a drop target
 * @param {DragEvent} event - The drag event
 */
function handleDrop(event) {
    event.preventDefault();

    // Remove visual feedback
    event.target.classList.remove('drag-over');

    // Get the drop zone and dragged item information
    const dropZone = event.target.closest('.drop-zone');
    if (!dropZone || !draggedElement) {
        return;
    }

    const itemCategory = draggedElement.getAttribute('data-category');
    const zoneCategory = dropZone.getAttribute('data-category');

    // Check if the item belongs to this category
    if (itemCategory === zoneCategory) {
        // Successful drop
        handleSuccessfulDrop(draggedElement, dropZone);
    } else {
        // Invalid drop
        handleInvalidDrop(itemCategory, zoneCategory);
    }
}

/**
 * Handle successful drop operation
 * @param {HTMLElement} item - The dragged item element
 * @param {HTMLElement} dropZone - The drop zone element
 */
function handleSuccessfulDrop(item, dropZone) {
    try {
        // Get the item data
        const itemId = item.getAttribute('data-id');
        const itemData = allItems.find(i => i.id == itemId);

        if (!itemData) {
            throw new Error('Item data not found');
        }

        // Create dropped item element
        const droppedItem = createDroppedItemElement(itemData);

        // Add to the appropriate drop zone container
        const droppedItemsContainer = dropZone.querySelector('.dropped-items');
        droppedItemsContainer.appendChild(droppedItem);

        // Remove the original item from the items container
        item.remove();

        // Update status message
        updateStatus(`✅ ${itemData.name} correctly placed in ${itemData.category}s!`, 'success');

        // Check if all items are categorized
        checkCompletion();

        console.log('Successfully dropped:', itemData.name);

    } catch (error) {
        console.error('Error in successful drop:', error);
        updateStatus('Error processing drop operation', 'error');
    }
}

/**
 * Handle invalid drop operation
 * @param {string} itemCategory - The category of the dragged item
 * @param {string} zoneCategory - The category of the drop zone
 */
function handleInvalidDrop(itemCategory, zoneCategory) {
    // Provide feedback for incorrect categorization
    updateStatus(`❌ That's a ${itemCategory}, not a ${zoneCategory}! Try again.`, 'error');

    // Add shake animation to provide visual feedback
    if (draggedElement) {
        draggedElement.style.animation = 'shake 0.5s';
        setTimeout(() => {
            draggedElement.style.animation = '';
        }, 500);
    }

    console.log('Invalid drop: tried to put', itemCategory, 'in', zoneCategory, 'zone');
}

/**
 * Create a dropped item element for the drop zone
 * @param {object} itemData - The item object
 * @returns {HTMLElement} - The created dropped item element
 */
function createDroppedItemElement(itemData) {
    const droppedItem = document.createElement('div');
    droppedItem.className = 'dropped-item';
    droppedItem.setAttribute('data-id', itemData.id);

    droppedItem.innerHTML = `
        <div class="item-name">${itemData.name}</div>
        `;

        // Set border color if available
        if (itemData.color) {
            droppedItem.style.borderColor = itemData.color;
        }

        return droppedItem;
}

/**
 * Check if all items have been categorized
 */
function checkCompletion() {
    const remainingItems = document.querySelectorAll('#items-container .draggable-item');

    if (remainingItems.length === 0) {
        updateStatus('🎉 Congratulations! You have successfully categorized all items!', 'success');

        // Add completion celebration
        setTimeout(() => {
            showCompletionCelebration();
        }, 500);
    }
}

/**
 * Show completion celebration effect
 */
function showCompletionCelebration() {
    // Create confetti effect or other celebration
    const statusElement = document.getElementById('status-message');
    statusElement.style.animation = 'pulse 1s infinite';

    // Optional: Add a reset button
    const resetButton = document.createElement('button');
    resetButton.textContent = 'Play Again';
    resetButton.style.marginLeft = '15px';
    resetButton.style.padding = '8px 16px';
    resetButton.style.backgroundColor = '#667eea';
    resetButton.style.color = '#ffffff';
    resetButton.style.border = 'none';
    resetButton.style.borderRadius = '5px';
    resetButton.style.cursor = 'pointer';

    resetButton.addEventListener('click', resetGame);
    statusElement.appendChild(resetButton);
}

/**
 * Reset the game to initial state
 */
function resetGame() {
    // Clear drop zones
    document.getElementById('fruit-items').innerHTML = '';
    document.getElementById('vegetable-items').innerHTML = '';

    // Re-render all items
    const shuffledItems = shuffleArray([...allItems]);
    renderItems(shuffledItems);

    // Reset status
    updateStatus('Game reset! Start categorizing items again.', 'info');

    // Remove reset button if exists
    const existingButton = document.querySelector('#status-message button');
    if (existingButton) {
        existingButton.remove();
    }
}

/**
 * Update the status message with feedback
 * @param {string} message - The status message to display
 * @param {string} type - The type of message: (success, error, info)
 */
function updateStatus(message, type) {
    const statusElement = document.getElementById('status-message');
    statusElement.textContent = message;

    // Remove existing status classes
    statusElement.classList.remove('success', 'error');

    // Add appropriate class based on type
    if (type === 'success' || type === 'error') {
        statusElement.classList.add(type);
    }

    // Auto-clear error messages after a delay
    if (type === 'error') {
        setTimeout(() => {
            if (statusElement.classList.contains('error')) {
                updateStatus('Drag items to their correct categories', 'info');
            }
        }, 3000);
    }
}

// Add CSS for shake and pulse animations
const animationStyles = document.createElement('style');
animationStyles.textContent = `
@keyframes shake {
    0%, 100% { transform: translateX(0); }
    10%, 30%, 50%, 70%, 90% { transform: translateX(-10px); }
    20%, 40%, 60%, 80% { transform: translateX(10px); }
}

@keyframes pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
}
`;
document.head.appendChild(animationStyles);