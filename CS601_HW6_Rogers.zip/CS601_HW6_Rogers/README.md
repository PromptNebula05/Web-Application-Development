# Fresh Market Grocery - Inventory Management Application

## Project Overview

This is a React-based inventory management web application for Fresh Market Grocery store (a notional market). The
application displays the store's current inventory in a clean, user-friendly interface with dynamic rendering of
product information. The current iteration enhances the application with React Router for navigation, detailed 
product pages, and comprehensive product information including images and descriptions.

## Features

### Core Features
- **React Components**: Modular component architecture with reusable InventoryItem components
- **State-Based Routing**: Seamless view switching using React state management
- **Product Detail Pages**: Individual pages for each product with comprehensive information
- **Clickable Inventory Items**: Each item switches to its detailed product page
- **Dynamic Data Loading**: Inventory data loaded from JSON file with enhanced product information
- **Product Images**: Visual product representations stored in the `/public` directory
- **Responsive Design**: Mobile-friendly layout that adapts to different screen sizes
- **Professional Styling**: Modern CSS with gradient backgrounds, hover effects, and animations
- **Complete Store Interface**: Includes store logo, name, tagline, inventory list, and footer

### New for this Iteration
- **State-Based View Switching**: Uses React state to toggle between inventory list and product detail views
- **ProductDetail Component**: Reusable component displaying full product information
- **Enhanced Inventory Data**: Products now include descriptions and images
- **Interactive Navigation**: Back buttons and clickable header for returning to home
- **Stock Availability Indicators**: Visual indicators for in-stock, low-stock, and out-of-stock items
- **Actions Buttons**: Mock "Add to Cart" and "Continue Shopping" functionality

## Project Structure

```
CS601_HW5_Rogers/
├── index.html              # Main HTML file with React components
├── styles.css              # CSS styling for the application
├── inventory.json          # Inventory data (7 items)
├── public/                 # Product images directory
│   ├── bananas.jpg         # Organic Bananas product image
│   ├── apples.jpg          # Gala Apples product image
│   ├── broccoli.jpg        # Fresh Broccoli product image
│   ├── bread.jpg           # Whole Wheat Bread product image
│   ├── pasta.jpg           # Organic Pasta product image
│   ├── orange-juice.jpg    # Orange Juice product image
│   ├── mixed-nuts.jpg      # Mixed Nuts product image
└── README.md               # Project documentation
```

## Technical Implementation

### React Setup
- **Approach**: Non-build setup using React CDN (v18)
- **Libraries Used**:
  - React v18 (via unpkg.com CDN)
  - ReactDOM v18 (via unpkg.com CDN)
  - Babel Standalone (for JSX transformation)

### Navigation Structure
- **State-Based Views**: Uses React state (`selectedSKU`) to control which view is displayed
- **Home View**: Displays the inventory list with all products (when `selectedSKU` is null)
- **Product Detail View**: Shows the detailed information for a specific product (when `selectedSKU` is set)
- **No External Routing**: Simple, reliable navigation without external dependencies

### Components

#### 1. **InventoryItem Component**
  - Displays a single inventory item with thumbnail image
  - Clickable div that triggers navigation to product details
  - Accepts props: sku, name, qty, price, image, onClick
  - Includes hover effects and "Click to view details" prompt

#### 2. **InventoryList Component**
  - Renders the complete list of inventory items
  - Uses array mapping to generate InventoryItem components
  - Passes all product data and click handler via props to child components

#### 3. **ProductDetail Component** (New)
  - Reusable component for displaying comprehensive product information
  - Receives product object and onBack callback as props
  - Displays: product image, name, SKU, price, quantity, availability, and description
  - Includes back navigation button to return to home
  - Shows error message for non-existent products
  - Features action buttons for user interaction

#### 4. **Header Component**
  - Displays store name and logo
  - Clickable header that triggers navigation back to home
  - Receives onLogoClick callback as prop

#### 5. **Footer Component**
  - Contains copyright information
  - Consistent across all pages

#### 6. **App Component (main)**
  - Root application component managing all state and views
  - Manages application state: inventory data, loading, error, and selectedSKU
  - Fetches inventory data from JSON file on mount using useEffect hook
  - Conditionally renders either ProductDetail or InventoryList based on selectedSKU state
  - Provides callback functions for navigation (handleItemClick, handleBackToHome)

## Notes

### Why Non-Build Approach?
The non-build approach was chosen to:
  - Simplify setup
  - Allow for quick testing and iteration
  - Focus on React core concepts and state management
  - Meet flexibility requirements
  - Enable easy code review and validation
  - Work reliably without requiring a development server